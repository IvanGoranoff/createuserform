import React, { useState, useEffect} from "react";
import "./App.css";
import { Grid, Paper, Button, Radio, FormControlLabel, FormLabel,  TextField, Autocomplete,FormControl,RadioGroup } from "@mui/material";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


function App() {
  const paperStyle = { padding: "30px 20px", width: 300, margin: "20px auto" };
  const marginTop = { marginTop: 5 };
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [gValue, setGValue] = useState('');
  const [gStatus, setGStatus] = useState('');
  const [autValue, setAutValue] = useState(null);
  const [userId, setUserId] = useState(null);
    const [userData, setUserData] = useState([]);
    
    useEffect(() => {
        fetchUsers();
    }, []);

    useEffect(() => {
     
        if (!autValue) {
            setUserName('');
            setUserEmail('')
            setGValue('')
            setGStatus('')
            
        }
    }, [autValue]);

    const fetchUsers = () => {
        axios
        .get("https://gorest.co.in/public/v2/users",
        {
            headers: {
            'x-access-token': 'application/json'
            }
        })
        .then((res) => {
            console.log(res);
            setUserData(res.data);
            
        })
        .catch((err) => {
            console.log(err);
            toast.error('Error', {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            })
        });
    };

    const onSubmit =(e) => {
        e.preventDefault();
        const validEmail = new RegExp(
            '^[a-zA-Z0-9._:$!%-]+@[a-zA-Z0-9.-]+.[a-zA-Z]$'
        );
        const hasEmailError = !validEmail.test(userEmail);

        if (hasEmailError) {
            return toast.error('Email not valid!');;
        }
            
        if (!autValue) {
            axios.post(
            'https://gorest.co.in/public/v2/users',
            {
                name: userName,
                email: userEmail,
                gender: gValue,
                status: gStatus,
            },
            {
                headers: {
                "Authorization": "Bearer 2a6ab6559bef841aa8dcb12c7c506981d2cbbf8c0f665abd175ca9ffe8b97369",
                "Content-Type": "application/json",
                "Accept": "application/json"
                },
            }
            
            ).then((res) => {
                // setUserData(res.data);
                console.log(res)
                toast.success('Successfully created');
                setUserName('');
                setUserEmail('')
                setGValue('')
                setGStatus('')

            });

        } else {
            axios.put(
                
                `https://gorest.co.in/public/v2/users/${userId}`,
                {
                    name: userName,
                    email: userEmail,
                    gender: gValue,
                    status: gStatus,
                },
                {
                    headers: {
                    "Authorization": "Bearer 2a6ab6559bef841aa8dcb12c7c506981d2cbbf8c0f665abd175ca9ffe8b97369",
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                    },
                }
                ).then((res) => {
                
                    console.log(res)
                    toast.success('Successfully updated');
                });
        }
    }

    const deleteUser= (item) => {
        let newVal = null;
        let newId = null;
        if(item?.id) {
            newVal = item;
            newId = item.id;
        axios.delete(`https://gorest.co.in/public/v2/users/${userId}`,
        {
            name: userName,
            email: userEmail,
            gender: gValue,
            status: gStatus,
        }, 
        {
            headers: {
            "Authorization": "Bearer 2a6ab6559bef841aa8dcb12c7c506981d2cbbf8c0f665abd175ca9ffe8b97369",
            "Content-Type": "application/json",
            "Accept": "application/json"
                },
        })
             .then((res) => {
                console.log(res)
           
               });
         
          
     }
     setUserId(newId);
     setAutValue(newVal);
     toast.success('Successfully deleted');
    }

    const handleChangeAutocomplete = (item) => {
        console.log(item);
        let newVal = null;
        let newId = null;
        if(item?.id) {
            newVal = item;
            newId = item.id;
            fetch(`https://gorest.co.in/public/v2/users/${item.id}`)
                .then((response) => response.json())
                .then((response) => {
                    
                    setUserName(response.name);
                    setUserEmail(response.email); 
                    setGValue(response.gender); 
                    setGStatus(response.status); 
                   
                    
                }) 
        }
        setUserId(newId);
        setAutValue(newVal);
    }

    const handleChancheAllFields = (e) => {
        if(e.target.name === "name") {
            setUserName(e.target.value)
        }
        if(e.target.name === "email") {
            setUserEmail(e.target.value)
        }
        if(e.target.name === "gender") {
            setGValue(e.target.value);
        }
        if(e.target.name === "status") {
            setGStatus(e.target.value);
        }
    }

  
    return (
        <div className="App">
            <ToastContainer position="top-right" autoClose={5000} hideProgressBar={false} newestOnTop={false} closeOnClick rtl={false} pauseOnFocusLoss draggable pauseOnHover />
                <Grid container spacing={2}>
                    <Grid item xs={6}>
                        <Autocomplete style={{position: 'absolute', left: '10%', top: '10%',}}                            
                            disablePortal
                            options={userData}
                            getOptionLabel={(option) => option.name}
                            value={autValue}
                            onChange={(event, newValue) => handleChangeAutocomplete(newValue)}
                            sx={{ width: 300 }}
                            renderInput={(params) => <TextField {...params} label="Users" />}
                        />
                    </Grid>                   
                    <Grid item xs={6}>
                        <Paper evelation={20} style={paperStyle}>
                            <form onSubmit={onSubmit}>
                                <TextField onChange={(e) => handleChancheAllFields(e)} name="name" margin="normal" value={userName} fullWidth label='Име' required="true" placeholder="Enter your name" />
                                <TextField onChange={(e) => handleChancheAllFields(e)} name="email"  margin="normal"  value={userEmail}  fullWidth required="true" label='Email' placeholder="Enter your email"  />         
                                <FormControl required="true" component="fieldset" style={marginTop}>
                                    <FormLabel component="legend">Gender</FormLabel>
                                    <RadioGroup aria-label="gender" required="true" onChange={(e) => handleChancheAllFields(e)} value={gValue} name="gender" style={{ display: 'initial' }}>
                                        <FormControlLabel value="female" control={<Radio required="true" />} label="Female" />
                                        <FormControlLabel value="male" control={<Radio required="true" />} label="Male" />
                                    </RadioGroup>
                                </FormControl>          
                                <FormLabel padding="2" required="true" component="legend">Status</FormLabel>
                                <RadioGroup aria-label="gender" required="true" onChange={(e) => handleChancheAllFields(e)} value={gStatus}  name="status" style={{ display: 'initial' }}>
                                <FormControlLabel value="active" control={<Radio required="true"/>} label="Active" />
                                <FormControlLabel value="inactive" control={<Radio required="true"/>} label="Inactive" />
                                    </RadioGroup>
                            
                                <Button type='submit'  variant='contained' color='primary'> {autValue ? 'Edit user' : 'Create user'}</Button>
                                <Button type='submit'  onClick={deleteUser} variant='contained' style={{marginLeft:5}}  color='primary'> Delete user</Button>
                            </form>
                        </Paper>
                    </Grid>
                </Grid>
        </div>
    );
}

export default App;
